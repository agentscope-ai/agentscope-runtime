from openai import OpenAI, AsyncOpenAI
import openai
import asyncio
import os
OPENAI_AVAILABLE = True

API_URL = ('https://poc-dashscope.aliyuncs.com/api/v2/apps/pre-agent'
           '/73d64bbc08c64cedb7101526669b458e/compatible-mode')

API_KEY = 'sk-35fdc7acbbe7492b8e57af193166bd3f'


async def run_native_openai_sdk_responses_create_streaming():
    """测试原生 OpenAI SDK responses.create 流式调用"""
    if not OPENAI_AVAILABLE:
        print('WARNING OpenAI SDK 不可用，跳过原生 SDK 流式测试')
        return

    print('\n🌊 测试原生 OpenAI SDK responses.create 流式调用')
    print('=' * 50)

    try:
        # 设置 OpenAI 客户端指向本地服务
        openai.api_base = API_URL
        openai.api_key = API_KEY  # 任意值，我们的 API 不需要认证
        os.environ['OPENAI_BASE_URL'] = API_URL
        os.environ['OPENAI_API_KEY'] = API_KEY
        async_openai_client = AsyncOpenAI()

        print('📝 调用 openai.responses.create (流式)...')

        response = await async_openai_client.responses.create(
            model='gpt-4',
            input=[{
                'role': 'user',
                'content': '写一篇阿里巴巴下一个财年的AI方向预测报告',
            }],
            stream=True,
        )

        print('SUCCESS 原生 SDK 流式调用成功')
        print('RAW 流式响应内容:')

        event_count = 0
        async for event in response:
            event_count += 1
            event_type = event.type if hasattr(event,
                                               'type') else 'unknown'
            print(f'   PACKAGE 事件 {event_count}: {event_type}: ')

            # 打印事件详情
            if hasattr(event, 'id'):
                print(f'      ID: {event.id}')
            if hasattr(event, 'created_at'):
                print(f'      创建时间: {event.created_at}')
            if hasattr(event, 'model'):
                print(f'      模型: {event.model}')

            # 打印内容相关字段
            content_fields = ['content', 'text', 'item', 'output']
            for field in content_fields:
                if hasattr(event, field):
                    value = getattr(event, field)
                    if value:
                        print(f'      {field}: {value}')

        print(f'   SUCCESS 流式响应完成，共接收 {event_count} 个事件')

    except Exception as e:
        print(f'ERROR 原生 OpenAI SDK 流式调用失败: {e}')
        import traceback

        traceback.print_exc()

def __init__(self, base_url: str = 'http://localhost:8000'):
    self.base_url = base_url
    self.api_url = f'{base_url}/v1'
    self.openai_api_url = f'{base_url}/v1'  # OpenAI SDK 会在后面添加 /responses
    self.openai_client = None
    self.async_openai_client = None

    if OPENAI_AVAILABLE:
        self.openai_client = OpenAI(
            api_key='test-key',  # 任意值，我们的 API 不需要认证
            base_url=self.api_url,
        )
        self.async_openai_client = AsyncOpenAI(api_key='test-key',
                                               base_url=self.api_url)


def run_native_openai_sdk():
    os.environ['OPENAI_BASE_URL'] = API_URL
    os.environ['OPENAI_API_KEY'] = API_KEY
    client = OpenAI()

    response = client.responses.create(
        model="any-name",
        input="天道酬勤下一句是什么？"
    )

    print(response)

if __name__ == '__main__':
    # asyncio.run(run_native_openai_sdk_responses_create_streaming())
    run_native_openai_sdk()