# -*- coding: utf-8 -*-
"""Template directory for deployment templates."""